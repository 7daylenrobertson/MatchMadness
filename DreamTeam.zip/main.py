import random
from ZS import getJobParam
from Daylen import getEmployeeParam
from Ahmad import promptsandweights
jobPost=getJobParam()
employeeProfile = getEmployeeParam()
count=0
#Matching algorithm
if jobPost["work_arrange"].lower()==employeeProfile["work_arrange"].lower():
  count+=1
  
if jobPost["location"].lower()==employeeProfile["location"].lower():
  count+=1

if employeeProfile["salary"]<=jobPost["salary"][0] and employeeProfile["salary"]<=jobPost["salary"][1]:
  count+=1

if jobPost["job_type"].lower()==employeeProfile["job_type"].lower():
  count+=1


  

#checks all of listed skills, if listed skill word matches skill by employee, checks year amount needed
for i in jobPost["skills"]:
  for j in employeeProfile["skills"]:
    if i[0].lower()==j[0].lower():
      if i[1].isnumeric():
        if j[1]>=i[1]:
          count+=2
        elif j[1]==i[1]-1:
          count+=1

#Same above for experience
for x in jobPost["experience"]:
  for y in employeeProfile["experience"]:
    if x[0].lower()==y[0].lower():
      if x[1].isnumeric():
        if y[1]>=x[1]:
          count+=2
        elif y[1]==x[1]-1:
          count+=1

if count>5:
  print(employeeProfile["name"]+"is a 50% technical match! :)")
elif count>8:
  print(employeeProfile["name"]+"is a 70% technical match! :)")
elif count>10:
  print(employeeProfile["name"]+"is a 90% technical match! :)")
elif count<5:
  print(employeeProfile["name"]+"is not a technical match :(")
      
print("Candidate's cultural fit score is:", promptsandweights(),"! :)")



##""""
##skills={}
##for i in range(5):
  #Skill                                   #years
##  skills[f[random.randint(0,len(f))][:-1]]:(random.randint(0,5))
##print(skills)

##experience=[]
##for i in range(5):
  #experience                                #years
##  experience[f[random.randint(0,len(f))][:-1]]:(random.randint(0,10))
##print(experience)
##""""