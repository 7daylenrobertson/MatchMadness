#personal info
  #name


  #location / preferred location *map of each
  #number
  #email
  #Authorized to work in the us?
    #visa?
    #do you need a visa?
  #pay minumimn? put 0 if none (amount)

#Education
  #Certs [type][level][year]*Verify(link or number)
  #Degree [type][study][completed?][year]
  #Study [studytopic] [years] *verify
  

#Skills
  #keywords [key bank]
#Higher weight


#Experience
  #title
  #years
    #keywords [key bank]  

def Employee(name, work_arrange, location, salary, job_type, skills, experience):
    employeeBio= {
    "name" : name,
    "work_arrange" : work_arrange,
    "location" : location,
    "salary" : salary,
    "job_type" : job_type,
    "skills" : skills,
    "experience" : experience
    }
    return employeeBio

# Contact Info (Email, Phone)




def getEmployeeParam():
  #get name
  name = input("Enter full Name: ")
  #get work_arrange
  work_arrange = input("Enter Work Arrangement (In Person/Remote): ")
  #get city and state for location
  city_location = input("Enter preferred city location(s):")
  state_Abrev = input("Enter Location State Abreviation (MD,TN,AL): ")
  location = city_location + ', ' + state_Abrev
  salary = int(input("Enter Minimum Salary: "))
  job_type = input("Enter Job Types Interested: ")
  skills=[("python",3),("communicate","N/A"),("excel",2)]
  experience=[("scrum",2), ("supervise",1)]
  employeeBio = Employee(name, work_arrange, location, salary, job_type, skills, experience)
  return employeeBio