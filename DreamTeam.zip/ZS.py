############### Part 1 ###################
#========= Get General Info of Job =======
# Get company name
def JobApplication(company, work_arrange, location, salary, job_type, experience, skills):
  jobApp = {
    "company" : company,
    "work_arrange" : work_arrange,
    "location" : location,
    "salary" : salary,
    "job_type" : job_type,
    "skills" : skills,
    "experience" : experience
  }
  return jobApp

    
# Contact Info (Email, Phone)
###########################################

def getJobParam():
  #get name
  company = input("Enter Company Name: ")
  #get work_arrange
  work_arrange = input("Enter Work Arrangement (In Person/Remote): ")
  #get city and state for location
  city_location = input("Enter Location City: ")
  state_Abrev = input("Enter Location State Abreviation (MD,TN,AL): ")
  location = city_location + ', ' + state_Abrev
  #get min and max salary for range of salary
  min_salary = int(input("Enter Minimum Salary: "))
  max_salary = int(input("Enter Max Salary: "))
  salary = (min_salary, max_salary)
  #get job_type (key words)
  job_type = input("Enter Job Type: ")
  experience=[("python",3),("communicate","N/A")]
  skills=[("scrum",2), ("supervise",1)]
  #get skills (key words)
  jobApp = JobApplication(company, work_arrange, location, salary, job_type, experience, skills)
  return jobApp