## algorithm 
## weighted system that outputs a percentage match based on inputs and weights
## how many questions 10 - 100
def promptsandweights():
    questions = {}
    targets = {}
    numberofquestions = int(input("How many questions would you like to include in your questionaire:"))
    for i in range(numberofquestions):
        question = input("Enter question number " + str(i + 1)+ ": ")
        target = int(input("(Recruiter) What's your ideal number"))
        score = int(input("How many points would you like to allocate to this question (importance):"))
        questions[question] = score
        targets[question] = target
    answerprompts(questions,targets)
    
def answerprompts(questions,targets):
    responses = {}
    for i in questions:
        response = int(input(("On a scale of 1-5, " + i)))
        responses[i] = response
    culturalscore(responses, targets,questions)
    
def culturalscore(responses, targets,questions):
    score = 0
    for i in questions:
        maxpoint = questions[i]
        diff = 0
        diff = abs(responses[i] - targets[i])
        for i in range(diff):
            maxpoint /=  1.25
        score+= maxpoint
    return score